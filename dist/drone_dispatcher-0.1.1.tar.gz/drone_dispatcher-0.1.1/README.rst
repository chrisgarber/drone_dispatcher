drone_dispatcher
================

An algorithm for connecting packages with a drone delivery service


Purpose
-------
This script gets a list of drones from the provided url, deserializes them to objects, then assigns them packages to deliver

Usage
-----
