from drone_dispatcher import drone_dispatcher

def main():
	dispatcher = drone_dispatcher()
	dispatcher.dispatchDrones()

if __name__ == "__main__":
	main()